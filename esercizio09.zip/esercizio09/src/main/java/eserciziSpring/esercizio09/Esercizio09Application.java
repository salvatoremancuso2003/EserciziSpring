package eserciziSpring.esercizio09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Esercizio09Application {

	public static void main(String[] args) {
		SpringApplication.run(Esercizio09Application.class, args);
	}

}
